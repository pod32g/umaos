Thank you for downloading this Umamusume cursor pack!!
===================================================================================

Head to this link for the most up to date README! Thank you for downloading this pack!

https://docs.google.com/document/d/11rdtfeZvk2nMGo2bChsvQeaRbc7f7rKb5sqk6Hr2Lo0/edit?usp=sharing

This cursor is version v1.7. Please update if the docs shows a newer version!

- all pixel art by pixloen (https://x.com/pixloen)
find more cursors at: https://ko-fi.com/pixloen/shop

-----------------------------------------------------------------------------------
Want to see more Umamusume cursors? Vote for your favorites in this poll!
https://forms.gle/ozd1CpVuZy5PTmUM9


-----------------------------------------------------------------------------------
Send feedback here!
https://forms.gle/2qnsGAYiw6tSL9P89

Note: These cursors are intended to be used at 1x pixel size, but do what you want with them.

===================================================================================
How to Install (Windows)
-----------------------------------------------------------------------------------

Right click on the Install.inf included in the Windows subfolder.
This will create a cursor scheme in the C:Windows\Cursor folder.

- Search for "Change the mouse pointer display or speed" on Windows.
- On the Mouse Properties window that pops up, click the "Pointers" tab on the top of the window.
- Select the Umamusume cursor scheme, then click apply.

OR

- Open Settings
- Search for "Mouse settings" and click on it
- On the bottom of the menu, click "Additional Mouse Settings"
- On the Mouse Properties window that pops up, click the "Pointers" tab on the top of the window.
- In the Customize area, click each cursor and Browse..., then after opening the cursor's "Windows" folder, select the Umamusume cursor with the matching name.
- Leave the Mouse Properties window open, and repeat this for each cursor. You do not need to click "OK" after selecting every cursor.
- Save the mouse scheme by clicking the "Save As" button, and click Apply on the bottom.


Note: The menu in Windows 11 "Accessibility > Mouse pointer and touch" is not recommended as the cursor may reset on Windows restart. Saving the mouse scheme prevents this issue.

Optional Things:
If the Text Select cursor is too large, you can instead use "Text Select 2", which is more standard.

How to Install  (Linux)
-----------------------------------------------------------------------------------
You can read instructions on how to install this cursor set below:
https://wiki.archlinux.org/title/Cursor_themes


How to Install (Mac)
-----------------------------------------------------------------------------------
You can find .png versions of the Windows cursors in the Mac subfolder.
Import these using Mousecape.

Frame timings:

Hand and Pointer Animations:
830ms, then 80ms until the tail is on the other side, then 830ms, repeat

Busy Animation:
160ms

https://github.com/alexzielenski/Mousecape

-----------------------------------------------------------------------------------

Troubleshooting (Windows)

If the cursor is translucent or bright, try the following:
	-Enable Pointer Shadow.
	-Check HDR settings, try turning it off and on, and adjusting the SDR Content Brightness slider.
	-Try changing the resolution of your monitor back and forth.
	-Open up Registry Editor / regedit
		-Navigate to HKEY_CURRENT_USER > Control Panel > Mouse
		-Change the value of "Mouse Trails" to -1, then restart your computer.
	-Check your GPU drivers, Nvidia especially. Try updating to the latest, or rolling back to 581.80.
	-If all else fails, try enabling Display pointer trails.

	Unfortunately, I am unable to replicate this issue with my cursors so I do not know if any of these methods work. 
	Seems to be driver related.

If the cursor reverts to the default Windows cursor when restarting, 
	-Put these cursors in C:\Windows\Cursors.
	-Save the cursors as a Cursor Scheme when applying.

